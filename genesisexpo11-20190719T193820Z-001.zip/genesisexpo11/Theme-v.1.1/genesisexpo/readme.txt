== Changelog ==
Version 1.0.14 - 13 December 2019
- Updated Page Builderry Plugin

Version 1.0.11 - 8.02.19
- Fixed issue with mobile menu
- Updated strings translate

Version 1.0.10 - 22.01.19
- Fixed strings translate
- Fixed demo import issues
- Fixed grid float at the team module
- Added support of cart for mobile device

Version 1.0.9 - 02.01.19
- Added tags selector for Double Heading Module

Version 1.0.7 - 5.12.18
- New option added  for related products
- Fixed team issues
- Updated plugins

Version 1.0.2 - 1.11.18
- Fixed issue with the child theme
- Fixed  small bug in Firefox

Version 1.0.1 - 27.10.18
- Added new Home Pages and Schedule Pages
- Fixed  button link in the Header Builder

Version 1.0 - 26.10.18
- Initial release